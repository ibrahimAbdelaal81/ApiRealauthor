const GENDERS_ENUM = ['male', 'female'];
module.exports = {
    GENDERS_ENUM,
};
