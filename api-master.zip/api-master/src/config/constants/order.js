const RECEIVED = "received";
const OUT = "out";
const COMPLETED = "completed";
const CANCELED = "canceled";
const ORDER_STATUS_ENUM = [RECEIVED, OUT, COMPLETED, CANCELED];
const ORDER_STATUS = { RECEIVED, OUT, COMPLETED, CANCELED };
module.exports = { ORDER_STATUS_ENUM, ORDER_STATUS };
