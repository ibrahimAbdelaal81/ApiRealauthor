const API_NAME = "Realauthor";

module.exports = {
  api: {
    name: API_NAME,
    version: "1.0",
    host: "localhost",
    port: process.env.PORT || 4200,
    contextStoreName: "api",
  },
  common: {
    pageSize: 10,
    maxPageSize: 100,
  },
  locales: {
    dataPath: `${__dirname}/locales`,
    dataExtension: ".json",
    supportedLocales: ["en", "ar", "_"],
  },
  storage: {
    accessKey: "KAEAQZLWWJ4CDCAUESGY",
    secretKey: "9XcznG1RSvIXm3+rLjVkGr0ZcPZeV3adU0f7O/k2EYo",
    baseUrl: "digitaloceanspaces.com",
    bucket: "ghadaq",
    region: "fra1",
    folder: "dev",
  },
  authentication: {
    key:
      "thisIsVerySecretKeyNoOneCanImagineThatThisIsTheKeyAndEvenIfHeImaginedThatThisIsTheKeyHeWillNotExpectThatIWroteThatHeImaginedThatIsTheKey",
    confirmationKey:
      "thisKeyIsUsedForConformationOfEmailsInRealAuthorAppIknowYouCanNotKnowThisKeyBecauseImadeIt",
  },
  mongo: {
    url: "mongodb://realauthor:MkK8p778qY3zLs5W@mongodb:27017/realauthor",
  },
  clientSide: {
    url: "https://realauthor.com",
  },
};
