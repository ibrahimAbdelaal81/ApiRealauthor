const userSchema = require("./schemas/userSchema");
const researchSchema = require("./schemas/researchSchema");
const authSchema = require("./schemas/auth");
module.exports = {
  userSchema,
  researchSchema,
  authSchema,
};
